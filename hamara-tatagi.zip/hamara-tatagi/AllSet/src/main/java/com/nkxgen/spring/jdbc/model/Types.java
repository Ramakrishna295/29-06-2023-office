package com.nkxgen.spring.jdbc.model;

public class Types {
	public String Typevalue;

	public void setTypevalue(String Typevalue) {
		this.Typevalue = Typevalue;
	}

	public String getTypevalue() {
		return Typevalue;
	}
}
