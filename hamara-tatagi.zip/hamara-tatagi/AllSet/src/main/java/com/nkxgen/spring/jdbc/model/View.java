package com.nkxgen.spring.jdbc.model;

public class View {
	private int id;

	public void setid(int id) {
		this.id = id;
	}

	public int getid() {
		return id;
	}
}
