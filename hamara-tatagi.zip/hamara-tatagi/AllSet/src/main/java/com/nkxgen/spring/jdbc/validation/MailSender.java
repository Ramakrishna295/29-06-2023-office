package com.nkxgen.spring.jdbc.validation;

public interface MailSender {
	String send(String to_user);

}
